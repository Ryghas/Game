-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 02, 2017 at 04:08 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `game`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY  (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `himpunan`
--

CREATE TABLE IF NOT EXISTS `himpunan` (
  `id` int(255) NOT NULL auto_increment,
  `username` varchar(15) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `himpunan`
--

INSERT INTO `himpunan` (`id`, `username`, `score`) VALUES
(5, 'Andy', 100),
(4, 'Agung', 100),
(6, 'coba', 80),
(7, 'agung', 100);

-- --------------------------------------------------------

--
-- Table structure for table `low`
--

CREATE TABLE IF NOT EXISTS `low` (
  `id` int(11) NOT NULL auto_increment,
  `soal` text NOT NULL,
  `a` text NOT NULL,
  `b` text NOT NULL,
  `c` text NOT NULL,
  `jwaban` int(2) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `low`
--

INSERT INTO `low` (`id`, `soal`, `a`, `b`, `c`, `jwaban`, `gambar`, `type`) VALUES
(2, 'Apa Kepanjangan Dari CB ?', 'Caracter Building', 'Caracter Bulding', 'Carism Building', 1, '', 'Poltekpos'),
(3, 'Apa warna Jurusan TI ?', 'Merah', 'Kuning', 'Biru', 1, '', 'Himpunan'),
(4, 'Apa warna Jurusan MB/MP ?', 'Orange', 'Hijau', 'Kuning', 2, '', 'Himpunan'),
(5, 'Apa warna Jurusan LB ?', 'Hijau', 'Orange', 'Kuning', 2, '', 'Himpunan'),
(6, 'Apa warna Jurusan AK ?', 'Orange', 'Biru', 'Kuning', 3, '', 'Himpunan'),
(7, 'Apa warna Jurusan SI ?', 'Biru', 'Merah', 'Kuning', 1, '', 'Himpunan'),
(8, 'Ada Berapa Jurusan D4 di Politeknik Pos Indonesia ?', '4', '5', '6', 1, '', 'Poltekpos'),
(9, 'Apa Nama Himpunan Jurusan TI ?', 'HMA', 'Himatif', 'Himalogbis', 2, '', 'Himpunan'),
(10, 'Apa Nama Himpunan Jurusan AK ?', 'Himalogbis', 'Himatif', 'HMA', 3, '', 'Himpunan'),
(11, 'Ada Berapa Jurusan D3 di Politeknik Pos Indonesia ?', '4', '5', '6', 2, '', 'Poltekpos'),
(12, 'Apa Nama Himpunan Jurusan LB ?', 'Himalogbis', 'Himatif', 'HMA', 1, '', 'Himpunan'),
(13, 'Mana Yang Bukan Merupakan Fasilitas Politknik Pos Indoesia ?', 'Perpustakaan', 'Laboratorium Kimia', 'Laboratorium Bahasa', 2, '', 'Poltekpos'),
(21, 'dibawah ini yang bukan merupakan prodi yang ada di politeknik pos', 'D3', 'D4', 'S1', 3, '', 'Poltekpos'),
(30, 'Siapakah nama dosen pada gambar di atas ?', 'Dini Hamidin, S.Si. MBA., MT.', ' Widia Resdiana, S.S., M.Pd.', 'I Made Yadi Dharma, S.Kom., M.Kom.', 2, 'widia.jpg', 'Poltekpos'),
(29, 'Siapakah nama dosen pada gambar di atas ?', 'Saepudin Nirwan, S.Kom, M.Kom.', 'Parman Sukarno, ST., MDC.', 'Marwanto Rahmatuloh, ST., MT.', 1, 'nirwan.jpg', 'Poltekpos'),
(31, 'Logo Himpunan Jurusan apakah gambar di atas ?', 'Akutansi', 'Logistik Bisnis', 'Tekhnik Informatika', 1, 'akutansi.jpg', 'Himpunan'),
(32, 'Logo Himpunan Jurusan apakah gambar di atas ?', 'Akutansi', 'Logistik Bisnis', 'Tekhnik Informatika', 2, 'himalog.jpg', 'Himpunan'),
(33, 'Logo Himpunan Jurusan apakah gambar di atas ?', 'Akutansi', 'Logistik Bisnis', 'Tekhnik Informatika', 3, 'himatifp.jpg', 'Himpunan'),
(34, 'Apa nama UKM pencinta alam di Politeknik pos Indonesia ?', 'RIMBA', 'GEMPAR', 'GEMPA', 2, '', 'UKM'),
(35, 'Apa nama UKM keagamaan di Politeknik pos Indonesia ?', 'Commitment', 'IRMA', 'Communication', 1, '', 'UKM'),
(36, 'Apa nama UKM dance di politeknik pos indonesia ?', 'Moderen Dance', 'Floppey', 'Popeys', 3, '', 'UKM'),
(37, 'Dibawah ini adalah dance yang ada pada popeys, kecuali', 'Kecak', 'Tradisional', 'BreakDance', 1, '', 'UKM'),
(38, 'Apa nama UKM untuk pencinta musik di kampus orange ?', 'Komposisi', 'Komposer', 'Kompaser', 2, '', 'UKM'),
(39, 'UKM beladiri apa yang ada pada kampus orange ?', 'Taekwondo', 'Boxer', 'Kapuera', 1, '', 'UKM'),
(40, 'Apa nama UKM yang selalu menyiarkan lagu dan mengupdate berita setiap hari ?', 'Komposer', 'K-Radio', 'PMK', 2, '', 'UKM'),
(41, 'Apa nama ukm keagamaan kristen yang ada di poltekpos ?', 'PMK', 'PKM', 'PMA', 1, '', 'UKM');

-- --------------------------------------------------------

--
-- Table structure for table `medium`
--

CREATE TABLE IF NOT EXISTS `medium` (
  `id` int(11) NOT NULL auto_increment,
  `soal` text NOT NULL,
  `jwaban` int(2) NOT NULL,
  `a` text NOT NULL,
  `b` text NOT NULL,
  `c` text NOT NULL,
  `gambar` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `medium`
--

INSERT INTO `medium` (`id`, `soal`, `jwaban`, `a`, `b`, `c`, `gambar`) VALUES
(3, 'Bagian Komputer yang berfungsi sebagai otak pemrosesan data dan perhitungan adalah.....', 1, 'Processor', 'Harddisk', 'Memory', ''),
(4, 'Setiap Komputr yang terhubung dengan jaringan dapat bertindak baik sebagai workstation maupun server disebut jaringan.....', 2, 'Bus', 'Peer to Peer', 'Local Area Network', ''),
(5, 'Salah satu tipe jaringan jomputer yang umum dijumpai adalah....', 3, 'Wireless', 'Wan', 'Client Server', ''),
(6, 'Berikut ini jenis topologi jaringan komputer, kecuali.....', 2, 'Ring', 'Wireless', 'Star', ''),
(7, 'Jumlah data yang dapat di transfer melalui jaringan dalam jangka waktu tertentu disebut.......', 3, 'Dial Up', 'DNS', 'Bandwith', ''),
(8, 'Skema desain pembangunan sebuah jaringan komputer dikenal dengan istilah.....', 3, 'Skalabilitas', 'Media Trasmisi', 'Topologi', ''),
(9, 'Aktivitas pengujian fungsinalitas satuan terkecil dari sebuah perangkat lunak adalah', 2, 'Integration Test', 'Unit Test', 'Straegi Perangkat Lunak', ''),
(10, 'Sruktur data, artsitektur perangkat lunak, prosedur detil dan karakteristik antar muka merupakan.....', 1, 'Perancangan', 'Pengujian', 'Pembuatan Kode', ''),
(11, 'Pengumpulan kebutuhan dengan fokus pada perangkat lunak adalah......', 1, 'Analisis kebutuhan perangkat lunak', 'Perancangan', 'Pembuatan Kode', ''),
(12, 'Membuat perancangan sementara yang berfokus pada penyajian kepada pelanggan adalah.....', 2, 'Pengumpulan Kebutuhan Sistem', 'Membangun Prototyping', 'Evaluasi Prototyping', ''),
(13, 'Memfokuskan pada karakeristik objek adalah.....', 3, 'Enkapsulasi', 'Hirarki', 'Abstraksi', ''),
(14, 'Apabila terjadi pembelian secara tunai, maka akan dicatat kedalam jurnal.....', 1, 'Jurnal Pengeluaran Kas', 'Jurnal Pembelian', 'Jurnal Penerimaan Kas', ''),
(15, 'Rumusan persamaan dasar akuntansi adalah.....', 2, 'Harta= Kewajiban-Modal', 'Harta= Kewajiban+Modal', 'Modal= Kewajiban+Harta', ''),
(16, 'Yang bukan termasuk sistem operasi adalah.....', 3, 'Windows XP', 'Windows Vista', 'Microsoft Office', ''),
(17, 'Tipe bilangan bulat dalam bahasa pascal dikenal sebagai', 1, 'Integer', 'Char', 'Boolean', ''),
(18, 'Menggambarkan program secara logika merupakan fungsi dari....', 2, 'Begin', 'Flowchart', 'Sistem Operasi', ''),
(21, 'Pelajaran yang wajib dijalani kalangan mahasiswa dalam Undang-undang, kecuali', 3, 'Pendidikan Agama', 'PPKN', 'Sap', '');

-- --------------------------------------------------------

--
-- Table structure for table `slow`
--

CREATE TABLE IF NOT EXISTS `slow` (
  `Id` int(255) NOT NULL auto_increment,
  `username` varchar(15) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `slow`
--

INSERT INTO `slow` (`Id`, `username`, `score`) VALUES
(35, 'agung', 0),
(34, 'oke', 80),
(33, 'Udin', 80),
(32, 'Arman', 60),
(30, 'agung', 60),
(31, 'Andi', 80),
(2, 'Indah', 90),
(1, 'Agung', 80);

-- --------------------------------------------------------

--
-- Table structure for table `ukm`
--

CREATE TABLE IF NOT EXISTS `ukm` (
  `id` int(255) NOT NULL auto_increment,
  `username` varchar(15) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ukm`
--

INSERT INTO `ukm` (`id`, `username`, `score`) VALUES
(3, 'Agung', 100),
(4, 'Army', 100),
(5, 'coba', 100);
